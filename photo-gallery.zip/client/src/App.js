import React, { useEffect, useState } from 'react';
import PhotoList from './components/PhotoList';
import PhotoForm from './components/PhotoForm';

function App() {
  const [photos, setPhotos] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/photos')
      .then((res) => res.json())
      .then((data) => setPhotos(data));
  }, []);

  const handleAddPhoto = (newPhoto) => {
    setPhotos((prevPhotos) => [...prevPhotos, newPhoto]);
  };

  return (
    <div className="App">
      <h1>My Photo Gallery</h1>
      <PhotoForm onAddPhoto={handleAddPhoto} />
      <PhotoList photos={photos} />
    </div>
  );
}

export default App;
