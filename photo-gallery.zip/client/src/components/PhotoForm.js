import React, { useState } from 'react';

function PhotoForm({ onAddPhoto }) {
  const [title, setTitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch('http://localhost:5000/photos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, imageUrl })
    });

    const newPhoto = await response.json();
    onAddPhoto(newPhoto);
    setTitle('');
    setImageUrl('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add New Photo</h2>
      <input
        type="text"
        placeholder="Photo Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Image URL"
        value={imageUrl}
        onChange={(e) => setImageUrl(e.target.value)}
        required
      />
      <button type="submit">Add Photo</button>
    </form>
  );
}

export default PhotoForm;
