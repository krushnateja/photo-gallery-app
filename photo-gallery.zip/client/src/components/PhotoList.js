import React from 'react';

function PhotoList({ photos }) {
  return (
    <div>
      <h2>Photo Gallery</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {photos.map((photo, index) => (
          <div key={index} style={{ margin: '10px' }}>
            <img src={photo.imageUrl} alt={photo.title} width="200" />
            <p>{photo.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default PhotoList;
