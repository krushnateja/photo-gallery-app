const mongoose = require('mongoose');

const PhotoSchema = new mongoose.Schema({
  title: String,
  imageUrl: String,
});

module.exports = mongoose.model('Photo', PhotoSchema);
