const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Photo = require('./models/Photo');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/photo_gallery', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.get('/photos', async (req, res) => {
  const photos = await Photo.find();
  res.json(photos);
});

app.post('/photos', async (req, res) => {
  const { title, imageUrl } = req.body;
  const photo = new Photo({ title, imageUrl });
  await photo.save();
  res.json(photo);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
